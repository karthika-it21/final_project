class Sidebar {
  clickOpenNewAccount() {
    cy.get('#leftPanel > ul > li:nth-child(1) > a').click();
  }

  clickAccountsOverview() {
    cy.get('#leftPanel > ul > li:nth-child(2) > a').click();
  }

  clickRequestLoan() {
    cy.get('#leftPanel > ul > li:nth-child(7) > a').click();
  }

  clickTransferFunds() {
    cy.get('#leftPanel > ul > li:nth-child(3) > a').click();
  }

  clickBillPayment(){
     cy.get('#leftPanel > ul > li:nth-child(4) > a').click({ force: true });
  }

}

export default new Sidebar();
