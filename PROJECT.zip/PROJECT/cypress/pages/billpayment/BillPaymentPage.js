


  class BillPaymentPage {
  // Navigate to Bill Pay via shared sidebar
  


  // Common submit button
  clickSubmit() {
    cy.get(':nth-child(14) > :nth-child(2)').click();
  }

  // Validation error getters
  getPayeeNameError() {
    return cy.get('#validationModel-name');
  }

  getAddressError() {
    return cy.get('#validationModel-address');
  }

  getCityError() {
    return cy.get('#validationModel-city');
  }

  getAccountEmptyError() {
    return cy.get('#validationModel-account-empty');
  }

  getAccountInvalidError() {
    return cy.get('#validationModel-account-invalid');
  }

  getVerifyAccountEmptyError() {
    return cy.get('#validationModel-verifyAccount-empty');
  }

  getVerifyAccountMismatchError() {
    return cy.get('#validationModel-verifyAccount-mismatch');
  }

  getAmountEmptyError() {
    return cy.get('#validationModel-amount-empty');
  }

  getAmountInvalidError() {
    return cy.get('#validationModel-amount-invalid');
  }

  // Field fillers
  fillAccountNumber(value) {
    cy.get(':nth-child(8) > :nth-child(2) > .input')
      .clear()
      .type(value);
  }

  fillVerifyAccount(value) {
    cy.get(':nth-child(9) > [width="20%"] > .input')
      .clear()
      .type(value);
  }

  fillAmount(value) {
    cy.get(':nth-child(11) > [width="20%"] > .input')
      .clear()
      .type(value);
  }

  // Fill all mandatory payee details
  fillPayeeDetails({ payeeName, address, city, state, zip, phone }) {
    cy.get(':nth-child(1) > [width="20%"] > .input').type(payeeName);
    cy.get(':nth-child(2) > [width="20%"] > .input').type(address);
    cy.get(':nth-child(3) > [width="20%"] > .input').type(city);
    cy.get(':nth-child(4) > [width="20%"] > .input').type(state);
    cy.get(':nth-child(5) > [width="20%"] > .input').type(zip);
    cy.get(':nth-child(6) > [width="20%"] > .input').type(phone);
  }

  // Success title getter
  getSuccessTitle() {
    return cy.get('#billpayResult > .title');
  }
}

export default new BillPaymentPage();
