class AccountsOverviewPage {
  getBalanceForAccount(accountNumber) {
    return cy
      .get('#showOverview')
      .contains('td', accountNumber)
      .parent()
      .find('td')
      .eq(1);
  }
}

export default new AccountsOverviewPage();
