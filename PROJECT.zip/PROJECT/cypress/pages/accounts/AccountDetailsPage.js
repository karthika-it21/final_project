class AccountDetailsPage {
  clickNewAccountLink() {
    cy.get('#newAccountId').click();
  }

  verifyAccountType(expectedType) {
    cy.get('#accountType').should('have.text', expectedType);
  }

  getAccountId() {
    return cy.get('#accountId');
  }

  getAvailableBalance() {
    return cy.get('#availableBalance');
  }
}

export default new AccountDetailsPage();
