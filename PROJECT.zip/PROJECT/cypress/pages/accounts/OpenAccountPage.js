class OpenAccountPage {
  selectAccountType(type) {
    cy.get('#type').select(type, { force: true });
  }

  selectFromAccountByIndex() {
    cy.get('#fromAccountId')
      .children()
      .first()
      .click({ force: true });
  }

  submit() {
    cy.get('form > div > .button').click();
  }

  getResultTitle() {
    return cy.get('#openAccountResult > .title');
  }

  getNewAccountLink() {
    return cy.get('#newAccountId');
  }
}

export default new OpenAccountPage();
