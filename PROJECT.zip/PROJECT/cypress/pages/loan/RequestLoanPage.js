class LoanRequestPage {
  fillAmount(amount) {
    cy.get('#amount').clear().type(amount);
  }

  selectFromAccount(accountNumber) {
    cy.get('#fromAccountId').select(accountNumber);
  }

  fillDownPayment(downPayment) {
    cy.get('#downPayment').clear().type(downPayment);
  }

  submit() {
    cy.get('[colspan="2"] > .button').click();
  }

  getLoanStatus() {
    return cy.get('#loanStatus');
  }
}

export default new LoanRequestPage();
