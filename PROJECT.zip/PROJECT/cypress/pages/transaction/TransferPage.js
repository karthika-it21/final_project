
const parseBalance = rawText =>
  parseFloat(rawText.replace(/[^0-9.]/g, ''));

class TransferPage {
  getAccountDetails(rowIndex) {
    return cy.get('tbody > tr')
      .eq(rowIndex)
      .then($row => {
        const number = $row.find('td').eq(0).text().trim();
        const balanceRaw = $row.find('td').eq(1).text();
        const balance = parseBalance(balanceRaw);
        return { number, balance };
      });
  }

  enterAmount(amount) {
    cy.get('#amount').clear().type(amount.toString());
  }

  selectFromAccount(accountNumber) {
    cy.get('#fromAccountId').select(accountNumber);
  }

  selectToAccount(accountNumber) {
    cy.get('#toAccountId').select(accountNumber);
  }

  submit() {
    cy.get('input.button').contains('Transfer').click();
  }

  getResultTitle() {
    return cy.get('#showResult > .title');
  }
}

export default new TransferPage();
