class LoginPage {
  visit() {
    cy.visit('https://parabank.parasoft.com/parabank/index.htm');
  }

  fillUsername(username) {
    cy.get('[name="username"]').clear().type(username);
  }

  fillPassword(password) {
    cy.get('[name="password"]').clear().type(password);
  }

  submit() {
    cy.get('[value="Log In"]').click();
  }

  getErrorTitle() {
    return cy.get('.title');
  }

  getErrorMessage() {
    return cy.get('.error');
  }

  clickRegister() {
    cy.get('#loginPanel > :nth-child(3) > a').click();
  }

  getOverviewTitle() {
    return cy.get('#showOverview > .title');
  }
}

export default new LoginPage();
