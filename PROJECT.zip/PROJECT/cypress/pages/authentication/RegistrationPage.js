class RegistrationPage {
  fillCustomerInfo({ firstName, lastName, street, city, state, zip, phone , ssn }) {
    cy.get(':nth-child(1) > [width="20%"]').type(firstName);
    cy.get(':nth-child(2) > [width="20%"]').type(lastName);
    cy.get(':nth-child(3) > [width="20%"]').type(street);
    cy.get(':nth-child(4) > [width="20%"]').type(city);
    cy.get(':nth-child(5) > [width="20%"]').type(state);
    cy.get(':nth-child(6) > [width="20%"]').type(zip);
    cy.get(':nth-child(7) > [width="20%"]').type(phone);
    cy.get(':nth-child(8) > [width="20%"]').click().type(ssn);
  }

  fillCredentials(username, password) {
    cy.get(':nth-child(10) > [width="20%"]').type(username);
    cy.get(':nth-child(11) > [width="20%"]').type(password);
    cy.get(':nth-child(12) > [width="20%"]').type(password);
  }

  submit() {
    cy.get('[colspan="2"] > .button').click();
  }

  getWelcomeTitle() {
    return cy.get('.title');
  }

  logout() {
    cy.contains('Log Out').click();
  }
}

export default new RegistrationPage();
