import LoginPage from '../pages/authentication/LoginPage';
import RegistrationPage from '../pages/authentication/RegistrationPage';
import Sidebar from '../pages/component/Sidebar';
import OpenAccountPage from '../pages/accounts/OpenAccountPage';
import AccountDetailsPage from '../pages/accounts/AccountDetailsPage';
import LoanRequestPage from '../pages/loan/RequestLoanPage';
import AccountsOverviewPage from '../pages/accounts/AccountsOverviewPage';
import TransferPage from '../pages/transaction/TransferPage';
import BillPaymentPage from '../pages/billpayment/BillPaymentPage';


describe('Parabank Authentication Flow', () => {
  const userName = 'qqriuc@gmail.com';
  const passWord = '12345';
  let fromAccount, toAccount, initialFromBalance, initialToBalance;

  before(() => {
    Cypress.on('uncaught:exception', () => false);
    LoginPage.visit();
  });

  it('Validate Login Functionality (invalid credentials)', () => {
    LoginPage.fillUsername(userName);
    LoginPage.fillPassword(passWord);
    LoginPage.submit();

    LoginPage.getErrorTitle().should('contain.text', 'Error!');
    LoginPage.getErrorMessage()
      .should('have.text', 'The username and password could not be verified.');
  });

  it('New User Registration', () => {
    LoginPage.clickRegister();

    RegistrationPage.fillCustomerInfo({
      firstName: 'New',
      lastName: 'Person',
      street: '33-A',
      city: 'Chicago',
      state: 'HYD',
      zip: '789065',
      phone: '0123456789',
      ssn:'12345'
    });

    RegistrationPage.fillCredentials(userName, passWord);
    RegistrationPage.submit();

    // wait for welcome title to appear
    cy.wait(5000);
    RegistrationPage.getWelcomeTitle()
      .should('have.text', `Welcome ${userName}`);

    RegistrationPage.logout();
  });

  it('Login with Registered credentials', () => {
    LoginPage.fillUsername(userName);
    LoginPage.fillPassword(passWord);
    LoginPage.submit();

   LoginPage.getOverviewTitle()
      .should('contain.text', 'Accounts Overview');
  });


 
   it('Opening new account', () => {
    Sidebar.clickOpenNewAccount();
    OpenAccountPage.selectAccountType('SAVINGS');
    OpenAccountPage.selectFromAccountByIndex();
    OpenAccountPage.submit();
    OpenAccountPage.getResultTitle().should('contain', 'Account Opened!');
  });

  let initialAccountNumber , initialBalance ;

  it('Verifying new account', () => {
      AccountDetailsPage.clickNewAccountLink();
      AccountDetailsPage.verifyAccountType('SAVINGS');
      AccountDetailsPage.getAccountId()
        .invoke('text')
        .then(text => {
          initialAccountNumber = text.trim();
        });
      AccountDetailsPage.getAvailableBalance()
        .invoke('text')
        .then(text => {
          initialBalance = parseFloat(text.replace(/[^0-9.-]+/g, ''));
        });
    });
 

 

 it('Verifying loan request status & updated balance', () => {
  Sidebar.clickRequestLoan();
  LoanRequestPage.fillAmount(100);
  LoanRequestPage.fillDownPayment(30);
  LoanRequestPage.selectFromAccount(initialAccountNumber);

  if (initialBalance > 30) {
    LoanRequestPage.submit();

    LoanRequestPage.getLoanStatus()
      .invoke('text')
      .should('contain', 'Approved');

    Sidebar.clickAccountsOverview();
    AccountsOverviewPage.getBalanceForAccount(initialAccountNumber)
      .invoke('text')
      .then(raw => {
        const newBal = parseFloat(raw.replace(/[^0-9.-]+/g, ''));
        expect(newBal).to.equal(initialBalance - 30);
      });

  } else {
    LoanRequestPage.submit();
    LoanRequestPage.getLoanStatus()
      .invoke('text')
      .should('contain', 'Denied');
  }
});




    it('Verify successful transaction', () => {
      Sidebar.clickAccountsOverview();

      TransferPage.getAccountDetails(0)
        .then(({ number, balance }) => {
          fromAccount = number;
          initialFromBalance = balance;
        });

      TransferPage.getAccountDetails(1)
        .then(({ number, balance }) => {
          toAccount = number;
          initialToBalance = balance;
        });

      cy.then(() => {
        Sidebar.clickTransferFunds();
        TransferPage.enterAmount(10);
        TransferPage.selectFromAccount(fromAccount);
        TransferPage.selectToAccount(toAccount);
        TransferPage.submit();
      });

  TransferPage.getResultTitle()
    .should('be.visible')
    .and('contain.text', 'Transfer Complete!');
});


   it('Verify transaction consistency', () => {
    cy.then(() => {
      Sidebar.clickAccountsOverview()

      // sender
      AccountsOverviewPage.getBalanceForAccount(fromAccount)
        .invoke('text')
        .then(text => {
          const updated = parseFloat(text.replace(/[^0-9.]/g, ''))
          const expected = initialFromBalance - 10
          expect(updated).to.equal(expected)
        })

      // receiver
      AccountsOverviewPage.getBalanceForAccount(toAccount)
        .invoke('text')
        .then(text => {
          const updated = parseFloat(text.replace(/[^0-9.]/g, ''))
          const expected = initialToBalance + 10
          expect(updated).to.equal(expected)
        })
    })
  })

  it('Transaction with insufficient balance', () => {
    cy.then(() => {
      // calculate an amount that definitely overdraws
      const overdraw = (initialFromBalance - 10) + 11

      Sidebar.clickTransferFunds();
      TransferPage.enterAmount(overdraw)
      TransferPage.selectFromAccount(fromAccount)
      TransferPage.selectToAccount(toAccount)
      TransferPage.submit()

      TransferPage.getResultTitle()
        .invoke('text')
        .should(text => {
          expect(text.trim()).not.to.equal('Transfer Complete!')
        })
    })
  })

//Bill Payment
  it('shows errors when mandatory fields are empty', () => {
    Sidebar.clickBillPayment();
    BillPaymentPage.clickSubmit();
    BillPaymentPage.getPayeeNameError()
      .should('be.visible')
      .and('contain', 'Payee name is required');
    BillPaymentPage.getAddressError()
      .should('be.visible')
      .and('contain', 'Address is required');
    BillPaymentPage.getCityError()
      .should('be.visible')
      .and('contain', 'City is required');
  });

  it('validates account number field', () => {
    BillPaymentPage.getAccountEmptyError()
      .should('be.visible')
      .and('contain', 'Account number is required');
    BillPaymentPage.fillAccountNumber('poo');
    BillPaymentPage.clickSubmit();
    BillPaymentPage.getAccountInvalidError()
      .should('be.visible')
      .and('contain', 'Please enter a valid number');
    BillPaymentPage.fillAccountNumber(90876);
  });

  it('validates verify-account field', () => {
    BillPaymentPage.getVerifyAccountEmptyError()
      .should('be.visible')
      .and('contain', 'Account number is required');
    BillPaymentPage.fillVerifyAccount(98765);
    BillPaymentPage.clickSubmit();
    BillPaymentPage.getVerifyAccountMismatchError()
      .should('be.visible')
      .and('contain', 'The account numbers do not match');
    BillPaymentPage.fillVerifyAccount(90876);
    BillPaymentPage.clickSubmit();
  });

  it('validates amount field', () => {
    BillPaymentPage.getAmountEmptyError()
      .should('be.visible')
      .and('contain', 'The amount cannot be empty');
    BillPaymentPage.fillAmount('poo');
    BillPaymentPage.clickSubmit();
    BillPaymentPage.getAmountInvalidError()
      .should('be.visible')
      .and('contain', 'Please enter a valid amount');
    BillPaymentPage.fillAmount(1000);
    BillPaymentPage.clickSubmit();
  });

  it('submits successfully when all fields are valid', () => {
    BillPaymentPage.fillPayeeDetails({
      payeeName: 'Poovi',
      address: 'Main Road',
      city: 'Chennai',
      state: 'Tamil Nadu',
      zip: 600007,
      phone: 9876567890
    });
    BillPaymentPage.clickSubmit();
    cy.wait(4000);
    BillPaymentPage.getSuccessTitle()
      .should('contain', 'Complete');
  });
});

 